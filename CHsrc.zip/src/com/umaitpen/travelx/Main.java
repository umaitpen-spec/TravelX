package com.umaitpen.travelx;

public class Main {
    public static final int VERSION_NO = 1;
    public static final String VERSION_NAME = "0.0.1";
    static void main() {

    }
}
