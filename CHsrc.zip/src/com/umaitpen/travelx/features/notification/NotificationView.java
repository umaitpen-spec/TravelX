package com.umaitpen.travelx.features.notification;

public class NotificationView {
}
