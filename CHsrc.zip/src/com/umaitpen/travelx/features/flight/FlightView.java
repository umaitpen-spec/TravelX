package com.umaitpen.travelx.features.flight;

public class FlightView {
}
