package com.umaitpen.travelx.features.payment;

public class PaymentView {
}
