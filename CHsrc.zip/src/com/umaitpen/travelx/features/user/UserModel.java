package com.umaitpen.travelx.features.user;

public class UserModel {
}
