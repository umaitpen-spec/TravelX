package com.umaitpen.travelx.features.signin;

public class SignInView {
    public SignInModel signInModel;
    public SignInView(SignInModel signInModel) {
        signInModel = new SignInModel();
    }
}
