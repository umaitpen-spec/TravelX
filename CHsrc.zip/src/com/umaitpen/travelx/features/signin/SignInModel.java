package com.umaitpen.travelx.features.signin;

public class SignInModel {
    public SignInView signInView;

    public SignInModel()
    {
        signInView = new SignInView(this);
    }
}
