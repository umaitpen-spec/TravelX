package com.umaitpen.travelx.features.report;

public class ReportView {
}
