package com.umaitpen.travelx.features.hotel;

public class HotelModel {
}
