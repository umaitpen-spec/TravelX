package com.umaitpen.travelx.features.signup;

public class SignUpModel {
}
