package com.umaitpen.travelx.data.dto;

public class Payment {
    private Long id;
    private Long bookingId;
    private Double amount;
    private PaymentMethod paymentMethod;
    private PaymentStatus paymentStatus;
    private String transactionId;
    private Long paymentDate;

    public enum PaymentMethod {
        CARD, UPI, NETBANKING
    }

    public enum PaymentStatus {
        SUCCESS, FAILED, PENDING
    }

    // Getters & Setters
}
