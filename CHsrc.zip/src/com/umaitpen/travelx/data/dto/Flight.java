package com.umaitpen.travelx.data.dto;

public class Flight {
    private Long id;
    private String flightNumber;
    private String source;
    private String destination;
    private Long departureTime;
    private Long arrivalTime;
    private Double price;
    private Integer totalSeats;
    private Integer availableSeats;
    private Long providerId;

    // Getters & Setters
}
