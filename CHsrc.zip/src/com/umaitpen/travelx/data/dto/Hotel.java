package com.umaitpen.travelx.data.dto;

public class Hotel {
    private Long id;
    private String name;
    private String location;
    private String description;
    private Double pricePerNight;
    private Integer totalRooms;
    private Integer availableRooms;
    private Long providerId;

    // Getters & Setters
}
