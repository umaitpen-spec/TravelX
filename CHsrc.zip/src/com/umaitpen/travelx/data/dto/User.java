package com.umaitpen.travelx.data.dto;

public class User {
    private Long id;
    private String name;
    private String email;
    private String password;
    private String mobileNo;
    private Role role;
    private Status status;
    private Long createdAt;

    public enum Role {
        CUSTOMER, PROVIDER, ADMIN
    }

    public enum Status {
        ACTIVE, INACTIVE
    }

    // Getters & Setters
}
