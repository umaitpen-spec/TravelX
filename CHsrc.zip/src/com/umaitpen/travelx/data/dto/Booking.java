package com.umaitpen.travelx.data.dto;

public class Booking {
    private Long id;
    private Long userId;
    private ServiceType serviceType;
    private Long serviceId;
    private Long bookingDate;
    private Long travelDate;
    private Integer quantity; // seats or rooms
    private Double totalAmount;
    private BookingStatus status;

    public enum ServiceType {
        HOTEL, FLIGHT
    }

    public enum BookingStatus {
        BOOKED, CANCELLED, COMPLETED
    }

    // Getters & Setters
}
