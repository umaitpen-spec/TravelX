package com.umaitpen.travelx.data.dto;

public class Cancellation {
    private Long id;
    private Long bookingId;
    private String reason;
    private Double refundAmount;
    private CancellationStatus status;
    private Long processedDate;

    public enum CancellationStatus {
        REQUESTED, APPROVED, REJECTED, REFUNDED
    }

    // Getters & Setters
}
