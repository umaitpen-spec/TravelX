package com.umaitpen.travelx.data.repository;

public class TravelXDB {
}
